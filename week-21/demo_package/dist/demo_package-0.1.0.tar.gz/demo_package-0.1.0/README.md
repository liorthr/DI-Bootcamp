markdown
# Demo Package

This is a demo Python package to illustrate creating and uploading a package to PyPI.