def say_hello():
    print("Hello from the demo package!")